const list = [
  {
    id: "1",
    employee_name: "Ali",
    employee_salary: "3333",
    employee_age: "22"
  },
  {
    id: "2",
    employee_name: "Omer",
    employee_salary: "334",
    employee_age: "22"
  },
  {
    id: "3",
    employee_name: "Hamza",
    employee_salary: "423",
    employee_age: "30"
  },
  {
    id: "4",
    employee_name: "Haris",
    employee_salary: "632",
    employee_age: "28"
  },
  {
    id: "5",
    employee_name: "Yunus",
    employee_salary: "8934",
    employee_age: "28"
  },
  {
    id: "6",
    employee_name: "Shakil",
    employee_salary: "432",
    employee_age: "29"
  }
];

export default list;
