export default {
  label: "Floor 1",
  viewBox: "-50 -40 1150 750",
  locations: [
    { name: "N Wall", id: "W1", path: "M 0 0 l 1100 0" },
    { name: "E Wall", id: "W2", path: "M 1100 0 l 0 700" },
    { name: "S Wall", id: "W3", path: "M 1100 700 l -1100 0" },
    { name: "W Wall", id: "W4", path: "M 0 700 l 0 -700" },

    {
      name: "Room 1",
      id: "R1001",
      path: "M 0 0, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 2",
      id: "R1002",
      path: "M 100 0, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 3",
      id: "R1003",
      path: "M 200 0, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 4",
      id: "R1004",
      path: "M 300 0, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 5",
      id: "R1005",
      path: "M 400 0, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 6",
      id: "R1006",
      path: "M 600 0, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 7",
      id: "R1007",
      path: "M 700 0, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 8",
      id: "R1008",
      path: "M 800 0, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 9",
      id: "R1009",
      path: "M 900 0, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 10",
      id: "R1010",
      path: "M 1000 0, l 100 0, l 0 100, l -100 0, l 0 -100"
    },

    {
      name: "Room 11",
      id: "R1011",
      path: "M 0 200, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 12",
      id: "R1012",
      path: "M 100 200, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 13",
      id: "R1013",
      path: "M 200 200, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 14",
      id: "R1014",
      path: "M 300 200, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 15",
      id: "R1015",
      path: "M 400 200, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 16",
      id: "R1016",
      path: "M 600 200, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 17",
      id: "R1017",
      path: "M 700 200, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 18",
      id: "R1018",
      path: "M 800 200, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 19",
      id: "R1019",
      path: "M 900 200, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 20",
      id: "R1020",
      path: "M 1000 200, l 100 0, l 0 100, l -100 0, l 0 -100"
    },

    {
      name: "Room 21",
      id: "R1021",
      path: "M 0 400, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 22",
      id: "R1022",
      path: "M 100 400, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 23",
      id: "R1023",
      path: "M 200 400, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 24",
      id: "R1024",
      path: "M 300 400, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 25",
      id: "R1025",
      path: "M 400 400, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 26",
      id: "R1026",
      path: "M 600 400, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 27",
      id: "R1027",
      path: "M 700 400, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 28",
      id: "R1028",
      path: "M 800 400, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 29",
      id: "R1029",
      path: "M 900 400, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 30",
      id: "R1030",
      path: "M 1000 400, l 100 0, l 0 100, l -100 0, l 0 -100"
    },

    {
      name: "Room 31",
      id: "R1031",
      path: "M 0 600, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 32",
      id: "R1032",
      path: "M 100 600, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 33",
      id: "R1033",
      path: "M 200 600, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 34",
      id: "R1034",
      path: "M 300 600, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 35",
      id: "R1035",
      path: "M 400 600, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 36",
      id: "R1036",
      path: "M 600 600, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 37",
      id: "R1037",
      path: "M 700 600, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 38",
      id: "R1038",
      path: "M 800 600, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 39",
      id: "R1039",
      path: "M 900 600, l 100 0, l 0 100, l -100 0, l 0 -100"
    },
    {
      name: "Room 40",
      id: "R1040",
      path: "M 1000 600, l 100 0, l 0 100, l -100 0, l 0 -100"
    }
  ]
};
