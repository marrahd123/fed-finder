import React from "react";
import "./styles.css";
import swal from "sweetalert";
import EmployeeAdd from "./Components/AddEmployee";
import SearchEmployee from "./Components/SearchEmployee";
import EmployeeTable from "./Components/EmployeeTable";
import list from "./Const/List/";
import { Button } from "react-bootstrap";
import { Modal } from "react-bootstrap";
import logo from "./assets/FedReserveLogo.svg";
import Floor from "./assets/floor1";
import Info from "./Components/Info";
import { RadioSVGMap } from "react-svg-map";
import "./App.css";
import Taiwan from "@svg-maps/taiwan";
import "react-svg-map/lib/index.css";

class Map extends React.Component {
  state = {};

  render() {
    return (
      <div className="Map">
        {" "}
        <RadioSVGMap map={Floor} />{" "}
      </div>
    );
  }
}

class App extends React.Component {
  state = {
    activehub: "Home",
    hubcontent: {
      hometab: "Home",
      searchtab: "Search",
      descriptortab: "Descriptor",
      helptab: "Help"
    }
  };
  render() {
    return (
      <div className="App">
        <div className="App-Nav">
          <img src={logo} className="App-Nav-Logo" alt="logo" />
          <div className="App-Search">
            <input
              type="text"
              className="search-input"
              placeholder="Search..."
            />
            <a className="search-button" />
          </div>
        </div>

        <div className="App-Body">
          <div className="App-Display">
            <Map floor={Floor} />
          </div>
          <div className="App-Info">
            <Info
              activehub={this.state.activehub}
              hubcontent={this.state.hubcontent}
            />
          </div>
        </div>
      </div>
    );
  }
}

export default App;
